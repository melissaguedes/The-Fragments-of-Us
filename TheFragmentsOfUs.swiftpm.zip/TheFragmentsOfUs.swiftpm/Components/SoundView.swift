import AVFoundation

class SoundManager {
    @MainActor static let playerInstance = SoundManager() // Instância única
    
    var effectsPlayer: AVAudioPlayer?
    
    func playClick() {
        guard let url = Bundle.main.url(forResource: "BUTTONCLICK", withExtension: ".mp3") else {
            print("Erro: arquivo ButtonSound.mp3 não encontrado no bundle.")
            return
        }

        do {
            try AVAudioSession.sharedInstance().setCategory(.playback, mode: .default)
            try AVAudioSession.sharedInstance().setActive(true)

            effectsPlayer = try AVAudioPlayer(contentsOf: url)
            effectsPlayer?.volume = 1.0 // Volume máximo
            effectsPlayer?.play()
        } catch {
            print("Erro ao reproduzir o som: \(error.localizedDescription)")
        }
    }

    
    // MARK: SOM BACKGROUND INÍCIO DO APP
//    func playBackground() {
//        guard let url = Bundle.main.url(forResource: "background", withExtension: ".mp3") else { return }
//                
//        do {
//            try AVAudioSession.sharedInstance().setCategory(.ambient, mode: .default)
//            try AVAudioSession.sharedInstance().setActive(true)
//            
//            backgroundPlayer = try AVAudioPlayer(contentsOf: url)
//            backgroundPlayer?.numberOfLoops = -2
//            backgroundPlayer?.volume = 1
//            backgroundPlayer?.play()
//        } catch {
//            print("error")
//        }
//    }
}
