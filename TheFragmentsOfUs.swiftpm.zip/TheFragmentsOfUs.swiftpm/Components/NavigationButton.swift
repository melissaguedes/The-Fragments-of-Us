//
//  Button.swift
//  TheFragmentsOfUs
//
//  Created by Melissa Freire Guedes on 06/12/24.
//

import SwiftUI

// Componente NavigationButton
struct NavigationButton<Destination: View>: View {
    var destination: Destination
    var body: some View {
        NavigationLink(destination: destination) {
            Image("Button")
                .resizable()
                .frame(width: 538, height: 143)
                .cornerRadius(15)
        }
        .buttonStyle(PlainButtonStyle()) 
    }
}
