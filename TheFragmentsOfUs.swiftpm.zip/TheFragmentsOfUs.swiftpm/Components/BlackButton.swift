//
//  BlackButton.swift
//  TheFragmentsOfUs
//
//  Created by Melissa Freire Guedes on 12/12/24.
//
import SwiftUI

struct CustomButtonBlack<Destination: View>: View {
    var destination: Destination
    var action: (() -> Void)? = nil // Ação adicional
    @State private var isActive: Bool = false // Estado para controlar a navegação
    
    var body: some View {
        Button(action: {
            action?() // Executa a ação adicional (exemplo: som)
            isActive = true // Ativa a navegação
        }) {
            Image("BlackButton")
                .resizable()
                .frame(width: 160, height: 160)
                .cornerRadius(100)
        }
        .buttonStyle(PlainButtonStyle())
        .background(
            NavigationLink(destination: destination, isActive: $isActive) {
                EmptyView()
            }
            .hidden() // Oculta o NavigationLink
        )
    }
}

#Preview {
    NavigationStack {
        CustomButtonBlack(destination: Text("Hello, World!"), action: {
            SoundManager.playerInstance.playClick()
        })
    }
}
