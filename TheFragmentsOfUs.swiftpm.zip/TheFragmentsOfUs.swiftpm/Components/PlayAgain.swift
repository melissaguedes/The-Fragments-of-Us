//
//  SwiftUIView.swift
//  TheFragmentsOfUs
//
//  Created by Melissa Freire Guedes on 12/12/24.
//

import SwiftUI

struct PlayAgainButton<Destination: View>: View {
    var destination: Destination
    
    var body: some View {
        NavigationLink(destination: destination) {
            Image("PlayAgainButton")
                .resizable()
                .frame(width: 538, height: 143)
                .cornerRadius(15)
        }
        .buttonStyle(PlainButtonStyle())
    }
}
