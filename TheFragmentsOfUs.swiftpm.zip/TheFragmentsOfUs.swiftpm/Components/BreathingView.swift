//
//  BreathButtonView.swift
//  TheFragmentsOfUs
//
//  Created by Melissa Freire Guedes on 06/12/24.
//

import SwiftUI
import SpriteKit

class BreathingScene: SKScene {
    var onFinishBreathing: (() -> Void)?
    private var circle: SKShapeNode!
    private var translucentCircles: [SKShapeNode]! = []
    private var guideLabel: SKLabelNode!
    private var finalMessageLabel: SKLabelNode!
    private var cycles = 0
    private var maxCycles = 2
    private var isBreathingActive = false
    private var petalCircles: [SKShapeNode] = []
    
    override func didMove(to view: SKView) {
        super.didMove(to: view)
        self.backgroundColor = .clear
        setupMainCircle()
               setupGuideLabel()
               setupFinalMessageLabel()
               setupTranslucentCircles()
        circle = SKShapeNode(circleOfRadius: 120)
        circle.fillColor = .darkGray
        circle.strokeColor = .clear
        circle.position = CGPoint(x: size.width / 2, y: size.height * 0.4)
        circle.setScale(1.0)
        addChild(circle)
        
        guideLabel = SKLabelNode(text: "")
        guideLabel.fontName = "SFPro-Bold"
        guideLabel.fontSize = 45
        guideLabel.fontColor = .white
        guideLabel.position = CGPoint(x: size.width / 2, y: size.height / 2 + size.height/3)
        addChild(guideLabel)
        
        finalMessageLabel = SKLabelNode(text: "Congrats!")
        finalMessageLabel.fontSize = 50
        finalMessageLabel.fontColor = .white
        finalMessageLabel.position = CGPoint(x: size.width / 2, y: size.height / 2)
        finalMessageLabel.alpha = 0
        addChild(finalMessageLabel)
    }
    private func setupMainCircle() {
            circle = SKShapeNode(circleOfRadius: 120)
            circle.fillColor = .darkGray
            circle.strokeColor = .clear
            circle.position = CGPoint(x: size.width / 2, y: size.height * 0.4)
            circle.setScale(1.0)
            addChild(circle)
        }
    private func setupGuideLabel() {
           guideLabel = SKLabelNode(text: "")
           guideLabel.fontName = "SFPro-Bold"
           guideLabel.fontSize = 45
           guideLabel.fontColor = .white
           guideLabel.position = CGPoint(x: size.width / 2, y: size.height / 2 + size.height / 3)
           addChild(guideLabel)
       }
//    private func createExpandingCircles() {
//        for i in 0..<5 { // Ajuste para controlar o número de círculos
//            let expandingCircle = SKShapeNode(circleOfRadius: 120)
//            expandingCircle.fillColor = .clear
//            expandingCircle.strokeColor = .white
//            expandingCircle.lineWidth = 2.0
//            expandingCircle.alpha = 0.5 // Transparência inicial
//            expandingCircle.position = circle.position
//            
//            addChild(expandingCircle)
//            
//            let delay = Double(i) * 0.3 // Atraso para criar um efeito sequencial
//            let scaleAction = SKAction.scale(to: 3.0, duration: 4.0) // Expansão
//            let fadeAction = SKAction.fadeOut(withDuration: 4.0) // Desvanece
//            let group = SKAction.group([scaleAction, fadeAction])
//            let sequence = SKAction.sequence([
//                SKAction.wait(forDuration: delay),
//                group,
//                SKAction.removeFromParent() // Remove após a animação
//            ])
//            
//            expandingCircle.run(sequence)
//        }
//    }
//    private func createFlowerEffect() {
//        let numberOfPetals = 10 // Quantidade de círculos ao redor
//        let radius: CGFloat = 80 // Distância do centro
//        let duration: TimeInterval = 5.0 // Duração da animação
//        petalCircles.forEach { $0.removeFromParent() }
//            petalCircles.removeAll()
//        for i in 0..<numberOfPetals {
//            let angle = CGFloat(i) * (2 * .pi / CGFloat(numberOfPetals)) // Calcula o ângulo para cada pétala
//            let petalCircle = SKShapeNode(circleOfRadius: 60)
//            petalCircle.fillColor = .cyan
//            petalCircle.strokeColor = .clear
//            petalCircle.alpha = 0.5
//            petalCircle.position = CGPoint(
//                x: circle.position.x + radius * cos(angle),
//                y: circle.position.y + radius * sin(angle)
//            )
//            
//            addChild(petalCircle)
//            petalCircles.append(petalCircle)
//            
////            let scaleAction = SKAction.scale(to: 2.0, duration: duration) // Expande
////            let fadeAction = SKAction.fadeOut(withDuration: duration) // Desvanece
////            let group = SKAction.group([scaleAction, fadeAction])
////            let sequence = SKAction.sequence([group, SKAction.removeFromParent()]) // Remove ao final
//            
////            petalCircle.run(sequence)
//        }
//    }
    private func createPetals() {
        let numberOfPetals = 12 // Quantidade de pétalas ao redor
        let radius: CGFloat = 90 // Distância inicial do centro

        // Remove pétalas existentes
        petalCircles.forEach { $0.removeFromParent() }
        petalCircles.removeAll()

        for i in 0..<numberOfPetals {
            let angle = CGFloat(i) * (2 * .pi / CGFloat(numberOfPetals))
            let petalCircle = SKShapeNode(circleOfRadius: 60) // Tamanho inicial pequeno
            petalCircle.fillColor = .lightGray
            petalCircle.strokeColor = .clear
            petalCircle.alpha = 0.0 // Invisível no início
            petalCircle.position = CGPoint(
                x: circle.position.x + radius * cos(angle),
                y: circle.position.y + radius * sin(angle)
            )

            addChild(petalCircle)
            petalCircles.append(petalCircle)
        }
    }
    private func animatePetalsShrinking(duration: TimeInterval) {
        let shrinkAction = SKAction.scale(to: 0.5, duration: duration) // Encolhe com o círculo
        let fadeOutAction = SKAction.fadeOut(withDuration: duration) // Gradualmente desaparece
        let group = SKAction.group([shrinkAction, fadeOutAction])

        for petal in petalCircles {
            petal.run(group) {
                petal.removeFromParent() // Remove do parent após desaparecer
            }
        }
    }
    private func animatePetalsGrowing(duration: TimeInterval) {
        let growAction = SKAction.scale(to: 1.5, duration: duration) // Cresce com o círculo
        let fadeInAction = SKAction.fadeAlpha(to: 0.5, duration: duration) // Fica mais visível
        let group = SKAction.group([growAction, fadeInAction])

        for petal in petalCircles {
            petal.run(group)
        }
    }

    private func setupFinalMessageLabel() {
            finalMessageLabel = SKLabelNode(text: "Congrats!")
            finalMessageLabel.fontSize = 50
            finalMessageLabel.fontColor = .white
            finalMessageLabel.position = CGPoint(x: size.width / 2, y: size.height / 2)
            finalMessageLabel.alpha = 0
            addChild(finalMessageLabel)
        }
    private func setupTranslucentCircles() {
           for i in 1...3 {
               let translucentCircle = SKShapeNode(circleOfRadius: CGFloat(120 + (i * 20)))
               translucentCircle.fillColor = .clear
               translucentCircle.strokeColor = .white
               translucentCircle.alpha = 0.3 - (CGFloat(i) * 0.05)
               translucentCircle.position = circle.position
               translucentCircles.append(translucentCircle)
               addChild(translucentCircle)
           }
       }
    
    func startBreathing() {
        isBreathingActive = true
        cycles = 0
        guideLabel.text = "Breath in..."
        runBreathingCycle()
    }
    
    func runBreathingCycle() {
        guard cycles < maxCycles else {
            finishBreathing()
            return
        }
        
        breatheIn {
            self.holdBreath {
                self.breatheOut {
                    self.cycles += 1
                    self.runBreathingCycle()
                }
            }
        }
    }
    func finishBreathing() {
        guideLabel.text = ""
        circle.run(SKAction.fadeOut(withDuration: 0.1))
        finalMessageLabel.run(SKAction.sequence([
            SKAction.fadeIn(withDuration: 1.0),
            SKAction.scale(to: 1.05, duration: 0.5),
                        SKAction.scale(to: 1.0, duration: 0.3)
                    ]))
        self.onFinishBreathing?()
    }
    func breatheIn(completion: @escaping () -> Void) {
            guideLabel.text = "Breath in..."
            
            circle.alpha = 1
            let growAction = SKAction.scale(to: 1.5, duration: 4.0) // Cresce em 4 segundos
            let colorChange = SKAction.colorize(with: .green, colorBlendFactor: 1.0, duration: 4.0)
            let group = SKAction.group([growAction, colorChange])
        createPetals()
            animatePetalsGrowing(duration: 4.0)
            circle.run(group) {
                completion()
            }
        //createFlowerEffect()
        }
    private func animateTranslucentCircles() {
            for (index, translucentCircle) in translucentCircles.enumerated() {
                let delay = Double(index) * 0.3 // Pequeno atraso entre os círculos
                let scaleUp = SKAction.scale(to: 2.0, duration: 4.0)
                let fadeOut = SKAction.fadeOut(withDuration: 4.0)
                let group = SKAction.group([scaleUp, fadeOut])
                let sequence = SKAction.sequence([
                    SKAction.wait(forDuration: delay),
                    group,
                    SKAction.removeFromParent() // Remove após a animação
                ])
                translucentCircle.run(sequence) {
                    translucentCircle.setScale(1.0) // Reseta o círculo
                    translucentCircle.alpha = 0.3 // Restaura a opacidade
                    self.addChild(translucentCircle) // Readiciona à cena
                }
            }
        }
        
    func holdBreath(completion: @escaping () -> Void) {
            guideLabel.text = "Hold..."
        //createFlowerEffect()
            let waitAction = SKAction.wait(forDuration: 3.0) // Segura por 3 segundos
            circle.run(waitAction) {
                completion()
            }
        }
    func breatheOut(completion: @escaping () -> Void) {
            guideLabel.text = "Breath out..."
            
            let shrinkAction = SKAction.scale(to: 0.5, duration: 4.0) // Encolhe em 4 segundos
            let colorChange = SKAction.colorize(with: .blue, colorBlendFactor: 1.0, duration: 4.0)
            let group = SKAction.group([shrinkAction, colorChange])
//        let fadeAction = SKAction.fadeOut(withDuration: 4.0)
//            let removeAction = SKAction.removeFromParent()
//            let sequence = SKAction.sequence([fadeAction, removeAction])
//        petalCircles.forEach { $0.run(sequence) } // Aplica a animação de desaparecer às pétalas
//           petalCircles.removeAll()
        animatePetalsShrinking(duration: 4.0)
            circle.run(group) {
                completion()
            }
        }
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
            guard let touch = touches.first else { return }
            let location = touch.location(in: self)
            
            // Verifica se o toque foi no círculo principal
            if circle.contains(location) {
                if !isBreathingActive {
                    let feedback = UIImpactFeedbackGenerator(style: .medium)
                    feedback.impactOccurred()
                    startBreathing()
                } else if finalMessageLabel.alpha == 1 {
                    resetScene()
                }
            }
        }
    func resetScene() {
        finalMessageLabel.run(SKAction.fadeOut(withDuration: 0.5))
            guideLabel.text = "Pressione o círculo para começar"
            circle.alpha = 1
            circle.setScale(1.0)
            circle.fillColor = .blue
            isBreathingActive = false
            cycles = 0
        }
}
struct BreathingView: View {
    @State private var navigateToNextScreen = false
    var scene: SKScene {
        let scene = BreathingScene(size: CGSize(width: 400, height: 800))
        scene.scaleMode = .resizeFill
        if let breathingScene = scene as? BreathingScene {
                    breathingScene.onFinishBreathing = {
                        withAnimation(.easeInOut(duration: 1)) {
                            navigateToNextScreen = true // Altera o estado para navegar
                        }
                    }
                }
        return scene
    }
    
    var body: some View {
        if navigateToNextScreen {
            FinalView()
//                .transition(.opacity)
                .ignoresSafeArea()
        } else {
            SpriteView(scene: scene)
                .ignoresSafeArea()
                .frame(width: 500, height: 500)
                .padding(.bottom, 300)
                .padding(.leading, 150)
                .padding(.trailing, 150)
                .onAppear {
                    AudioManager.shared.playSound(named: "BREATHING")
                }
            
        }
//        NavigationLink(
//            destination: DoraIntroView(),
//                           isActive: $navigateToNextScreen,
//                           label: { EmptyView() } // Esconde o botão de navegação
//                       )
    }
}

#Preview {
    BreathingView()
}
