import SwiftUI

struct ContentView: View {
    @State private var isNavigating = false // Controla a navegação

    var body: some View {
        NavigationStack {
            GeometryReader { geometry in
                ZStack {
                    Image("Inicial")
                        .resizable()
                        .scaledToFill()
                        .ignoresSafeArea()
//                        .padding(.bottom, 50)
                    
                    VStack {
                        Spacer()
                        NavigationButton( destination: ChapterOneView())
                            .padding(.top, 420)
                            .background(
                                NavigationLink(
                                    destination: ChapterOneView(),
                                    isActive: $isNavigating,
                                    label: { EmptyView() }
                                )
                                .hidden()
                            )
                        Spacer()
                    }
                }
                .frame(
                    width: geometry.size.width,
                    height: geometry.size.height,
                    alignment: .bottom
                )
                //.navigationTitle("Main View")
            }
            .onAppear {
                AudioManager.shared.playSound(named: "HAPPYSONG")
            }

        }
        .ignoresSafeArea()
        .navigationBarBackButtonHidden(true)
        .navigationViewStyle(StackNavigationViewStyle())
    }
}

