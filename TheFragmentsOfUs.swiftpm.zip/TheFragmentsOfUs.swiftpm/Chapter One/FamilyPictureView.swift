//
//  FamilyPictureView.swift
//  TheFragmentsOfUs
//
//  Created by Melissa Freire Guedes on 06/12/24.
//

import SpriteKit
import SwiftUI

class DragNode: SKSpriteNode { }

class FamilyPictureScene: SKScene {
    var draggableSquares = [SKSpriteNode]()
    var frameNode: SKSpriteNode!
    
    var frameSize: CGSize = .zero
    
    var drops: [SKNode] = []
    
    override func didMove(to view: SKView) {
        backgroundColor = .white
        createFrame()
        addDraggableSprite(imageName: "image1 1", position: CGPoint(x: 200, y: 650))
        addDraggableSprite(imageName: "image2 1", position: CGPoint(x: 1000, y: 650))
        addDraggableSprite(imageName: "IMAGE30", position: CGPoint(x: 200, y:400))
        addDraggableSprite(imageName: "image4 1", position: CGPoint(x: 1000, y: 400))
        
    }
    func createFrame() {
        let texture = SKTexture(imageNamed: "Frame")
        
        frameNode = SKSpriteNode(
            texture: texture,
            size: CGSize(
                width: texture.size().width ,
                height: texture.size().height
            )
        )
        frameNode.anchorPoint = .init(x: 0.5, y: 0.5)

        frameNode.position = CGPoint(
            x: frameSize.width/2.0,
            y: frameSize.height/1.77
        )
        
        frameNode.setScale(0.8)
        
        addChild(frameNode)
        
        let side = texture.size().width * 0.65
        let dropArea = SKSpriteNode(
            color: .white,
            size: CGSize(
                width: side,
                height: side
            )
        )
        dropArea.anchorPoint = .init(x: 0.5, y: 0.5)
        
        
        dropArea.position = CGPoint(
            x: frameSize.width/2 - 6,
            y: frameSize.height/1.77
        )
        dropArea.zPosition = 1
        
      
        addChild(dropArea)
        
        let r1 = SKSpriteNode(
            color: .clear,
            size: CGSize(
                width: side/2,
                height: side/2
            )
        )
        
        r1.anchorPoint = .init(x: 0, y: -1)
        
        r1.name = "image1 1"
        
        r1.position = CGPoint(x: dropArea.frame.minX, y: dropArea.frame.minY)
        
        r1.zPosition = 2
        
        addChild(r1)
        
        let r2 = SKSpriteNode(
            color: .clear,
            size: CGSize(
                width: side/2,
                height: side/2
            )
        )
        
        r2.anchorPoint = .init(x: 0, y: -1)
        r2.name = "image2 1"
        
        r2.position = CGPoint(x: dropArea.frame.midX, y: dropArea.frame.minY)
        
        r2.zPosition = 2
        
        addChild(r2)
        let r3 = SKSpriteNode(
            color: .clear,
            size: CGSize(
                width: side/2,
                height: side/2
            )
        )
        
        r3.anchorPoint = .init(x: 1, y: 0)
        r3.name = "IMAGE30"
        
        r3.position = CGPoint(x: dropArea.frame.midX, y: dropArea.frame.minY)
        
        r3.zPosition = 2
        
        addChild(r3)
        let r4 = SKSpriteNode(
            color: .clear,
            size: CGSize(
                width: side/2,
                height: side/2
            )
        )
        
        r4.anchorPoint = .init(x: 0, y: 0)
        
        r4.name = "image4 1"
        
        r4.position = CGPoint(x: dropArea.frame.midX, y: dropArea.frame.minY)
        
        r4.zPosition = 2
        
        addChild(r4)
        
        drops.append(r1)
        drops.append(r2)
        drops.append(r3)
        drops.append(r4)
        
        

    }
    
    func addDraggableSprite(imageName: String, position: CGPoint) {
        let texture = SKTexture(imageNamed: imageName)
        let sprite = DragNode(texture: texture, size: CGSize(width: 183, height: 183))
        sprite.position = position
        sprite.name = imageName
        sprite.zPosition = 2
        draggableSquares.append(sprite)
        addChild(sprite)
    }
    
    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard let touch = touches.first else { return }
        let location = touch.location(in: self)
        
        if let touchedNode = nodes(at: location).first as? DragNode {
            touchedNode.position = location
        }
    }
    
    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard let touch = touches.first else { return }
        let location = touch.location(in: self)

        if let touchedNode = nodes(at: location).first as? DragNode {
            
            if let touchedSprite = touchedNode as? SKSpriteNode, touchedSprite.texture != nil {
                
                guard let name = touchedSprite.name else {
                    return
                }
                
                guard let drop = drops.first(where: { $0.frame.contains(location) }) else {
                    return
                }
                
                if drop.name == name {
                    //print("match")
                    let action = SKAction.move(to: CGPoint(x: drop.frame.midX, y: drop.frame.midY), duration: 0.2)
                    touchedSprite.run(action)
                    touchedSprite.isUserInteractionEnabled = false
                }
            }
        }
    }
}

struct BackgroundWithSceneView: View {
    var body: some View {
        GeometryReader { geometry in
            ZStack(alignment: .bottom) {
                Image("familyPictureee")
                    .resizable()
                    .scaledToFill()
//                    .padding(.bottom, 50)
                    .navigationBarBackButtonHidden(true)
//                    .frame(maxWidth: .infinity)
//                    .frame(maxHeight: .infinity)
                SpriteKitContainer(size: geometry.size)
            }
            .frame(
                width: geometry.size.width,
                height: geometry.size.height,
                alignment: .bottom
            )
        }
        .ignoresSafeArea()

    }
}

struct FamilyPictureView: View {
    var body: some View {
        ZStack {
            GeometryReader { geometry in
                BackgroundWithSceneView()
                CustomButton(destination: FamilyBuildView(), action: {
                    SoundManager.playerInstance.playClick()
                })
                .padding(.top, geometry.size.height * 0.8)
                .padding(.leading, geometry.size.width * 0.85)
            }
        }
    }
}

struct SpriteKitContainer: UIViewRepresentable {
    let size: CGSize
    
    func makeUIView(context: Context) -> SKView {
        let skView = SKView()
        let scene = FamilyPictureScene()
        scene.frameSize = size
        scene.scaleMode = .resizeFill
        skView.presentScene(scene)
        skView.ignoresSiblingOrder = true
        skView.frame = scene.frame
        scene.backgroundColor = .clear
        skView.backgroundColor = .clear
        
        return skView
    }

    func updateUIView(_ uiView: SKView, context: Context) {
    }
}

#Preview {
    FamilyPictureView()
}
