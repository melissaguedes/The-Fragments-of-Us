//
//  FinalView.swift
//  TheFragmentsOfUs
//
//  Created by Melissa Freire Guedes on 06/12/24.
//

import SwiftUI

struct FinalView: View {
    var body: some View {
        GeometryReader { geometry in
            ZStack(alignment: .bottom) {
                Image("HappyFamilyy")
                    .resizable()
                    .scaledToFill()
                    .navigationBarBackButtonHidden(true)
            }
            .frame(
                width: geometry.size.width,
                height: geometry.size.height,
                alignment: .bottom
            )
            .ignoresSafeArea()
            
            CustomButton(destination: FinalTextView(), action: {
                SoundManager.playerInstance.playClick()
            })
            .padding(.top, geometry.size.height * 0.78)
            .padding(.leading, geometry.size.width * 0.85)
        }
        .onAppear {
            AudioManager.shared.playSound(named: "HAPPYSONG")
        }
        .ignoresSafeArea()
    }
}

#Preview {
    FinalView()
}
