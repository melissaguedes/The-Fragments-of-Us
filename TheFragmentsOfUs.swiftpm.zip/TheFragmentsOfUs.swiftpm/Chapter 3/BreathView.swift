//
//  SwiftUIView.swift
//  TheFragmentsOfUs
//
//  Created by Melissa Freire Guedes on 12/12/24.
//

import SwiftUI

struct BreathView: View {
    var body: some View {
        GeometryReader { geometry in
            ZStack {
                BreathingView()
                Image("Breath")
                    .resizable()
                    .scaledToFill()
                    .ignoresSafeArea()
    //                .padding(.bottom, 50)
                    .navigationBarBackButtonHidden(true)
                    .border(.black, width: 1)
    //            BlackButton(destination: BreathView())
    //                .padding(.top, 630)
    //                .padding(.leading, 970)
                BreathingView()
                    .frame(
                        width: geometry.size.width,
                        height: geometry.size.height,
                        alignment: .bottom
                    )
                
    //                .frame(width: 500, height: 500)
    //                .padding(.bottom, 200)
                    //.padding(.top, 300)
    //                .padding(.leading, 150)
    //                .padding(.trailing, 150)
                    //.border(.pink)
            }
            .ignoresSafeArea()
        }
//        .onAppear {
//            AudioManager.shared.playSound(named: "")
//        }
    }
}

#Preview {
    BreathView()
}
