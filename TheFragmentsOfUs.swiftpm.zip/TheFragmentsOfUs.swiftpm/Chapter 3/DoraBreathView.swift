//
//  SwiftUIView.swift
//  TheFragmentsOfUs
//
//  Created by Melissa Freire Guedes on 12/12/24.
//

import SwiftUI

struct DoraBreathView: View {
    var body: some View {
        GeometryReader { geometry in
            ZStack(alignment: .bottom) {
                Image("DoraBreathh")
                    .resizable()
                    .scaledToFill()
                //.ignoresSafeArea()
                    .navigationBarBackButtonHidden(true)
                    .border(.black, width: 1)
            }
            .frame(
                width: geometry.size.width,
                height: geometry.size.height,
                alignment: .bottom
            )
            CustomButtonBlack(destination: BreathExerciseView(), action: {
                SoundManager.playerInstance.playClick()
            })
            .padding(.top, geometry.size.height * 0.80)
            .padding(.leading, geometry.size.width * 0.85)
        }
        
        .ignoresSafeArea()
    }
}

#Preview {
    DoraBreathView()
}
