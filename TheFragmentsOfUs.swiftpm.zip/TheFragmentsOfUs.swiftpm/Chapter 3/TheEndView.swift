//
//  TheEnd.swift
//  TheFragmentsOfUs
//
//  Created by Melissa Freire Guedes on 06/12/24.
//
import SwiftUI

struct TheEndView: View {
    @State private var isNavigating = false // Controla a navegaçã

    var body: some View {
        NavigationView {
            GeometryReader { geometry in
                ZStack {
                    Image("Final")
                        .resizable()
                        .scaledToFill()

                    
                    VStack {
                        Spacer()
                        PlayAgainButton(destination: ContentView())
                            .padding(.top, 420)
                        .background(
                            NavigationLink(
                                destination: ChapterOneView(),
                                isActive: $isNavigating,
                                label: { EmptyView() }
                            )
                            .hidden()
                        )
                        Spacer()
                    }
                }
                .frame(
                    width: geometry.size.width,
                    height: geometry.size.height,
                    alignment: .bottom
                )
            }
            .ignoresSafeArea()
            //.navigationTitle("Main View")
        }
        .navigationBarBackButtonHidden(true)
        .navigationViewStyle(StackNavigationViewStyle())
    }
}

#Preview {
    TheEndView()
}

