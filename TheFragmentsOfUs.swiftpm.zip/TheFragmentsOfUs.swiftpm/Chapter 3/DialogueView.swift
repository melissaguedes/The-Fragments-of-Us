//
//  DoraTalksView.swift
//  TheFragmentsOfUs
//
//  Created by Melissa Freire Guedes on 06/12/24.
//

import SwiftUI

enum Phases {
    case one
    case two
    case three
    case four
}

struct MainDialogueView: View {
    @State var currentPhase: Phases = .one
    
    var body: some View {
        ZStack {
            switch currentPhase {
            case .one:
                DialogueView(phase: $currentPhase)
            case .two:
                DialogueTwoView(phase: $currentPhase)
            case .three:
                DialogueThreeView(phase: $currentPhase)
            case .four:
                DoraBreathView()
                    .opacity(currentPhase == .four ? 1 : 0) // Controla a opacidade
                                        .transition(.opacity)
            }
        }
        .animation(
                    currentPhase == .four ? .easeInOut(duration: 1.0) : .none, // Transição lenta
                    value: currentPhase
                )
    }
    
}

struct DialogueView: View {
    @Binding var phase: Phases
    @State private var draggablePosition: CGPoint = CGPoint(x: 580, y: 780)
    @State private var showHint = false
    let framePosition: CGPoint = CGPoint(x: 320, y: 220)
    let frameSize: CGSize = CGSize(width: 500, height: 143)

    var body: some View {
        GeometryReader { geometry in
            ZStack {
                Image("bg")
                    .resizable()
                    .scaledToFill()
                    .frame(width: geometry.size.width, height: geometry.size.height, alignment: .bottom)
                    .border(.black, width: 1)
//                    .padding(.bottom, 50)

                Image("LeftMoldura")
                    .resizable()
                    .frame(width: frameSize.width, height: frameSize.height)
                    .position(framePosition)
                    .opacity(0.5)

                Image("DoraDialogue1 1")
                    .resizable()
                    .frame(width: frameSize.width, height: frameSize.height)
                    .position(draggablePosition)
                    .offset(y: showHint ? -20 : 0) // Animação de dica para cima
                    .animation(.easeInOut(duration: 0.8).repeatCount(3, autoreverses: true), value: showHint)
                    .gesture(
                        DragGesture()
                            .onChanged { value in
                                draggablePosition = CGPoint(x: value.location.x, y: value.location.y)
                            }
                            .onEnded { _ in
                                if isInsideFrame(dragPosition: draggablePosition, framePosition: framePosition, frameSize: frameSize) {
                                    draggablePosition = framePosition
                                    phase = .two
                                }
                            }
                    )
            }
            .onAppear {
                draggablePosition = CGPoint(x: geometry.size.width/2, y: geometry.size.height - 100)
                DispatchQueue.main.asyncAfter(deadline: .now() + 1) {
                    showHint = true
                    DispatchQueue.main.asyncAfter(deadline: .now() + 2.8) {
                        showHint = false
                    }
                }
            }
            .navigationBarBackButtonHidden(true)
            .frame(width: geometry.size.width, height: geometry.size.height)
        }
        .ignoresSafeArea()
    }

    func isInsideFrame(dragPosition: CGPoint, framePosition: CGPoint, frameSize: CGSize) -> Bool {
        let frameRect = CGRect(
            x: framePosition.x - frameSize.width / 2,
            y: framePosition.y - frameSize.height / 2,
            width: frameSize.width,
            height: frameSize.height
        )
        return frameRect.contains(dragPosition)
    }
}

struct DialogueView_Previews: PreviewProvider {
    static var previews: some View {
        MainDialogueView()
    }
}
