//
//  SwiftUIView.swift
//  TheFragmentsOfUs
//
//  Created by Melissa Freire Guedes on 13/12/24.
//

import SwiftUI
struct DialogueThreeView: View {
@Binding var phase: Phases
@State private var draggablePosition: CGPoint = CGPoint(x: 590, y: 790) // Posição inicial da imagem arrastável
let framePosition: CGPoint = CGPoint(x: 886, y: 500) // Posição fixa da moldura
let frameSize: CGSize = CGSize(width: 535, height: 145) // Tamanho da moldura
@State private var showHint = false


var body: some View {
    GeometryReader { geometry in
        ZStack {
            Image("Dialogue4BGGG")
                .resizable()
                .scaledToFill()
                .frame(width: geometry.size.width, height: geometry.size.height, alignment: .bottom)
            
            
            Image("RightMoldura")
                .resizable()
                .frame(width: frameSize.width, height: frameSize.height)
                .position(framePosition)
                .opacity(0.5)

            
            Image("dadDialogue")
                .resizable()
                .frame(width: frameSize.width, height: frameSize.height)
                .position(draggablePosition)
                .offset(y: showHint ? -20 : 0)
                .animation(.easeInOut(duration: 0.8).repeatCount(3, autoreverses: true), value: showHint)
                .gesture(
                    DragGesture()
                        .onChanged { value in
                            draggablePosition = CGPoint(x: value.location.x, y: value.location.y)
                        }
                        .onEnded { _ in
                            if isInsideFrame(dragPosition: draggablePosition, framePosition: framePosition, frameSize: frameSize) {
                                draggablePosition = framePosition
                                phase = .four
                            }
                        }
                )
        }
        .onAppear {
            draggablePosition = CGPoint(x: geometry.size.width/2, y: geometry.size.height - 100)
            DispatchQueue.main.asyncAfter(deadline: .now() + 1) {
                showHint = true
                DispatchQueue.main.asyncAfter(deadline: .now() + 2.8) {
                    showHint = false
                }
            }
        }
        .navigationBarBackButtonHidden(true)
        .frame(width: geometry.size.width, height: geometry.size.height)
    }
    .ignoresSafeArea()
}
func isInsideFrame(dragPosition: CGPoint, framePosition: CGPoint, frameSize: CGSize) -> Bool {
    let frameRect = CGRect(
        x: framePosition.x - frameSize.width / 2,
        y: framePosition.y - frameSize.height / 2,
        width: frameSize.width,
        height: frameSize.height
    )
    return frameRect.contains(dragPosition)
}
}
#Preview {
    
}
