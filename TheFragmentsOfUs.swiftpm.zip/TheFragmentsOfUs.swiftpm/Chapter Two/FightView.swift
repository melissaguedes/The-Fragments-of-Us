//
//  FighTview.swift
//  TheFragmentsOfUs
//
//  Created by Melissa Freire Guedes on 06/12/24.
//


import SwiftUI

struct FightView: View {
    var body: some View {
        GeometryReader { geometry in
            ZStack(alignment: .bottom) {
                Image("FightVieww")
                    .resizable()
                    .scaledToFill()
                //.ignoresSafeArea()
                    .navigationBarBackButtonHidden(true)
            }
            .frame(
                width: geometry.size.width,
                height: geometry.size.height,
                alignment: .bottom
            )
            CustomButtonBlack(destination:HelpDoraView(), action: {
                SoundManager.playerInstance.playClick()
            })
            .padding(.top, geometry.size.height * 0.80)
            .padding(.leading, geometry.size.width * 0.85)
        }
        .onAppear {
            AudioManager.shared.playSound(named: "SAD")
        }
        
        .ignoresSafeArea()
    }
}

#Preview {
    ChangesView()
}
